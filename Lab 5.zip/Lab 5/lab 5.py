from random import randint   #import Random elements
from Levels import Level     #import Level printer

class Character:                #start Charictar class
  def __init__(self):      #inniate name helth, and max health
    self.name = ""
    self.health = 1
    self.health_max = 1
  def do_damage(self, enemy):       #define do damage
    damage = min(                   # define min and max damaage doable
        max(randint(0, self.health) - randint(0, enemy.health), 0),
        enemy.health)
    enemy.health = enemy.health - damage    #enemy heath decreases with damage
    if damage == 0: print ("%s evades %s's attack." % (enemy.name, self.name))   #if dammage is 0 you missed
    else: print ("%s hurts %s!" % (self.name, enemy.name))  #print who hurt who
    return enemy.health <= 0    
  
class Enemy(Character):    #start ememy class
  def __init__(self, player):    #iniate parent class of charictar, name, helth, and
    Character.__init__(self)    #number of ememies
    self.name = 'a goblin' 
    self.health = randint(1, player.health)
    self.numenimies = 1
 # def GetName:
      
class Player(Character):   #define player charictar
  def __init__(self):
    Character.__init__(self)  #innitate parent class, self state, helth, and max health
    self.state = 'normal'
    self.health = 10
    self.health_max = 10
  def quit(self):    #if quit then die
    print ("%s can't find the way back home, and dies of starvation.\nR.I.P." % self.name)
    self.health = 0
  def help(self): print (Commands.keys())   #if help print out dictionary
  def status(self):  #if status display how many monstorts are left and heath over max health
    print ("%s's health: %d/%d" % (self.name, self.health, self.health_max))
    print('there are ', Enemy.numenimies, 'monstors left')
  def tired(self):#if tired loose 1 health
    print ("%s feels tired." % self.name)
    self.health = max(1, self.health - 1)
  def rest(self): # if your state isnt normal you cant rest
    if self.state != 'normal': print ("%s can't rest now!" % self.name); self.enemy_attacks()
    else:
      print ("%s rests." % self.name)  #other wise of you have a number between 0 and 1
      if randint(0, 1):     #then you will be woken by the monstors
        self.enemy = Enemy(self)
        print("%s is rudely awakened by %s!" % (self.name, self.enemy.name))
        self.state = 'fight'
        self.enemy_attacks()
      else:    #if slept good, them add health
        if self.health < self.health_max:
          self.health = self.health + 1     #if health is full, loose health
        else: print ("%s slept too much." % self.name); self.health = self.health - 1
  def explore(self):   #if youre not normal you cant explore
    if self.state != 'normal':
      print ("%s is too busy right now!" % self.name)
      self.enemy_attacks()
    else:  #if you are normal you explore
      print ("%s explores a twisty passage." % self.name)
      if Enemy.numenimies != 0:  #if there are not 0 enimires you encounter a monstor
        self.enemy = Enemy(self)
        print ("%s encounters %s!" % (self.name, self.enemy.name))
        self.state = 'fight'  #fight the monstor
      else:    # if there are no more monstors left you dont need to explore anymore
        if Enemy.numenimies == 0: print('there are no more monsters left'); self.tired()
  def flee(self):  #run awayyy
    if self.state != 'fight': print ("%s runs in circles for a while." % self.name); self.tired()
    else:    #if not fight run arround a but and loose health
      if randint(1, self.health + 5) > randint(1, self.enemy.health):
        print ("%s flees from %s." % (self.name, self.enemy.name))
        self.enemy = None    #if your random num is more than the other random, then you can flee
        self.state = 'normal'  #and return to normal, otherwise you cant escape
      else: print ("%s couldn't escape from %s!" % (self.name, self.enemy.name)); self.enemy_attacks()
  def attack(self):  #define attack
    if self.state != 'fight': print ("%s swats the air, without notable results." % self.name); self.tired()
    else:    #if you arnt fighting then you swing and loose health
      if self.do_damage(self.enemy):   #do damage to enemy
        print ("%s executes %s!" % (self.name, self.enemy.name))
        self.enemy = None   #killed the enemy, remove enemy, from the level
        self.state = 'normal'
        Enemy.numenimies = Enemy.numenimies - 1
        if randint(0, self.health) < 10:  #if ran is less than 10 them add one helth to max andcurrent
          self.health = self.health + 1
          self.health_max = self.health_max + 1
          print ("%s feels stronger!" % self.name)  #get stroger
      else: self.enemy_attacks()   # otherwise, if still alive, attack again
  def enemy_attacks(self):  #if enemy kills you print that you dies
    if self.enemy.do_damage(self): print ("%s was slaughtered by %s!!!\nR.I.P." %(self.name, self.enemy.name))

  def LevelUp(self): #if there are no enemies then you can level up
    if Enemy.numenimies != 0:   #otherwise you cant level up
        print('you need to kill all monsters before leveling up')
    else:  #set up new level
        LevelSize.Height = randint(10, 25)
        LevelSize.Length = randint(10, 40)
        Enemy.numenimies = randint(0,5)

 
class LevelSize:  #set up level size
    def __init__(self):   #initalize height and length
        self.Height = 10
        self.Length = 10
    def Height():    #set heihght and lenth
        self.Height = randint(10, 25)
    def Length():
        self.Length = randint(10, 40)
        
Commands = {       #diffent commands in dictionaty definding keys to functions
  'quit': Player.quit,
  'help': Player.help,
  'status': Player.status,
  'rest': Player.rest,
  'explore': Player.explore,
  'flee': Player.flee,
  'attack': Player.attack,
  'level up': Player.LevelUp,
 # 'level down': Player.LevelDown,
  }
 
p = Player() # initalize Player class as p
p.name = input("What is your character's name? ")   #set up player name
print ("(type help to get a list of actions)\n")  #instructions
print ("%s enters a dark cave, searching for adventure." % p.name)  #drama
LevelSize.Height = randint(10, 25)  #set up first level
LevelSize.Length = randint(10, 40)
Enemy.numenimies = randint(0,5)

while(p.health > 0): #while your helth is more tham 0
  Level.PrintLevel(LevelSize.Height, LevelSize.Length, Enemy.numenimies)
  line = input("> ")   #print out level and input command
  args = line.split()
  if len(args) > 0:
    commandFound = False
    for c in Commands.keys():  #for all command keys
      if args[0] == c[:len(args[0])]:
        Commands[c](p)   #look for functions in player class
        commandFound = True     #if true run loop again
        break
    if not commandFound:     #if no command found then 
      print ("%s doesn't understand the suggestion." % p.name)
