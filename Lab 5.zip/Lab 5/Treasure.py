from random import randint   #import
from random import randrange
import random

class Treasure:   #start class
    def __init__(self):   #initate
        self.Gold = 100
        self.Armor = 'Armor'
        self.Food = 1
        self.Wepon = 'Sword'
    def GetGold(self):
        self.Gold = Gold + randint(1, 10)
    def PrintGold(self):
        print(self.Gold)

Treasure.GetGold
print (Treasure.Gold)
