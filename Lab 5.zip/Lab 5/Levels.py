from random import randint  #import the fun stuff
from random import randrange
import random

class Level:   #set up class
    def PrintLevel(Height, Length, numenimies):
        Map = []       #define printlevel and its atguments, 
        char = '*'
        for squares in range(1, Height+1):
            if squares == 1 or squares == Height:   #print out empty rectangle
                Map.append(str(char*Length))
            else:
                Map.append(str(char+(Length-2) * ' '+char))
        for i in range(numenimies):  #for however many enemies there are:
            y = random.choice(range(1,len(Map)-1))  #pick a random number from 1 to height
            X = str(Map[y])   #use that row and convery to string
            A = random.choice(range(1,len(X)-1))   #pick a random charictar in that string
            B = list(Map[y])  #convert string to list
            B[A] = 'M'   #use the random charictar (thats not a wall) and put monstor there
            Str = ''.join(B) #turn the list back into a string
            Map[y] = Str #replace that row with the new string with a monstor in it
        y = random.choice(range(1,len(Map)-1))   #do the same thing with a up stairs and down stairs
        X = str(Map[y])
        A = random.choice(range(1,len(X)-1))
        B = list(Map[y])
        B[A] = 'U'
        Str = ''.join(B)
        Map[y] = Str
        y = random.choice(range(1,len(Map)-1))
        X = str(Map[y])
        A = random.choice(range(1,len(X)-1))
        B = list(Map[y])
        B[A] = 'P'
        Str = ''.join(B)
        Map[y] = Str        
            #for each line, print the room again
        for i in Map:
            print(i)

